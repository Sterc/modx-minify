<?php
/**
 * @package modxminify
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modxminifygroup.class.php');
class modxMinifyGroup_mysql extends modxMinifyGroup {}
?>