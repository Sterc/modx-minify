<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# Modx Minify

Modx Minify is a MODX CMP to group and minify your CSS, SCSS, LESS and JS files. You can create groups, and each group can contain multiple files of the same type. So for instance you create a group named \'css\' where you can add all your css, scss and less files. After that you place the snippet call ``[[!modxMinify?&group=`css`]]`` inside a `<link>` tag in your head and a minified css file will be generated which will contain all your files grouped and minified!

## Usage
* Install the package via Package Management
* Add groups and files via the cmp
* Inside your <head> in your template, place the snippet call, for example: 

``<link rel="stylesheet" type="text/css" href="[[!modxMinify?&group=`css`]]" />``

The modxMinify snippet generates one minified file from all the files added to your specified group. The snippet automatically detects changes in your files, and also checks for changes made in the CMP (adding, updating, removing or reordering of files).

## Combining groups
You can also combine multiple groups into one minified file, by using a comma-separated list of groups in your [[!modxMinify]] snippet call:

``[[!modxMinify?&group=`css,css2`]]``

In the above example all the files from group \'css\' and \'css2\' get combined into one minified CSS file.

# Free Extra
This is a free extra and the code is publicly available for you to change. The extra is being actively maintained and you\'re free to put in pull requests which match our roadmap. Please create an issue if the pull request differs from the roadmap so we can make sure we\'re on the same page.

Need help? [Approach our support desk for paid premium support.](mailto:service@sterc.com)
',
    'setup-options' => 'modxminify-1.0.4-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'b16a6738cda011fa423319af12ec34d8',
      'native_key' => 'modxminify',
      'filename' => 'MODX/Revolution/modNamespace/71cda1e2715df606c9e9b257d155ba8a.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f6e2d0766c243418b9b10b4ff13a45cd',
      'native_key' => 'modxminify.user_name',
      'filename' => 'MODX/Revolution/modSystemSetting/0522b173ba846e258a951b7d22a11f0d.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '567b164e77245432e48b1166f6ebc467',
      'native_key' => 'modxminify.user_email',
      'filename' => 'MODX/Revolution/modSystemSetting/fe05474c0cd4fa314b2739cfa5f40a54.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9da3c99f4f6ccc238977f16892cbb673',
      'native_key' => 'modxminify.cache_path',
      'filename' => 'MODX/Revolution/modSystemSetting/708553962fac0e9b49060375af2d685d.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '25364b0cee0a0c7f2b3cb38fc0bd9f36',
      'native_key' => 'modxminify.cache_url',
      'filename' => 'MODX/Revolution/modSystemSetting/6cc668dea0f668a85090b58991026d2c.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'e09995a04032d81682b4263c252115d8',
      'native_key' => 'e09995a04032d81682b4263c252115d8',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/8d2bfc96b47464ef91bd96751bea5526.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '13acc4d9e2e50ab1a8d273a76f4b1b7d',
      'native_key' => 'modxminify.menu.modxminify',
      'filename' => 'MODX/Revolution/modMenu/4841b79d583f7b0bfe173852d84975ba.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '3160a1cd9f4a78b6ee512165356a531e',
      'native_key' => '3160a1cd9f4a78b6ee512165356a531e',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/f9487a224c74f43d6512189c6f5a1722.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'a5f81b5331f77a0f900b8d6f40134e97',
      'native_key' => 'a5f81b5331f77a0f900b8d6f40134e97',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/f1e72587839b77753690538e3421e31d.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '4a5c8fa7e17d719efb6ab46fe2a40c15',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/04a395110c64ee4f1de665bd35293aaf.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '24b0c8db38a1a9e2db961d728dc64ebd',
      'native_key' => '24b0c8db38a1a9e2db961d728dc64ebd',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/3d992d7296a0b0ac6cb549fc5fbc2d9b.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'bc08d70299a4fbe1bac0824d7ec01112',
      'native_key' => 'bc08d70299a4fbe1bac0824d7ec01112',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/ba62e9c42996c26a0ec209c0721ede31.vehicle',
    ),
  ),
);