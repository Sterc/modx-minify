<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# ModxMinify

ModxMinify is a MODX extra for compiling SCSS and LESS files, grouping and minifying CSS and JS assets.

Create named groups of files, then use the `modxMinify` snippet to output a single minified file per group.

## Usage

1. Install the package via Package Management
2. Add groups and files via the CMP
3. Place the snippet in your template\'s `<head>`:

```html
<link rel="stylesheet" type="text/css" href="[[!modxMinify? &group=`css`]]" />
<script src="[[!modxMinify? &group=`js`]]"></script>
```

The `modxMinify` snippet generates one minified file from all files in the specified group. It automatically detects changes in your files and any modifications made in the CMP (adding, updating, removing, or reordering files).

## Combining groups

You can combine multiple groups into one minified file by passing a comma-separated list of group names to `modxMinify`:

```
[[!modxMinify? &group=`vendor_css,theme_css`]]
```

In the above example all files from the `vendor_css` and `theme_css` groups are combined into one minified CSS file.

## System Settings

All settings use the `modxminify.` namespace and can be configured in the MODX manager under System Settings.

| Setting      | Key                     | Default                  | Description                                            |
| ------------ | ----------------------- | ------------------------ | ------------------------------------------------------ |
| `cache_path` | `modxminify.cache_path` | `{assets_path}cache`     | Path to the directory where minified files are stored. |
| `cache_url`  | `modxminify.cache_url`  | `{assets_url}cache`      | URL to the cache directory for serving minified files. |

### MODX installed in a subdirectory

If your MODX installation lives under a subdirectory (e.g. `mydomain.com/subdirectory/`), the default `{assets_url}` will include the subdirectory prefix, which can cause the cache folder to be created at the wrong path. Set the system settings manually:

| Setting             | Example value                                    |
| ------------------- | ------------------------------------------------ |
| `modxminify.cache_path` | `/var/www/html/subdirectory/assets/components/modxminify/cache/` |
| `modxminify.cache_url`  | `/subdirectory/assets/components/modxminify/cache/` |

## Dependencies

ModxMinify uses [Assetic](https://github.com/kriswallsmith/assetic) as its asset pipeline, with the following libraries handling compilation and minification:

| Library                                                          | Purpose           |
| ---------------------------------------------------------------- | ----------------- |
| [scssphp/scssphp](https://github.com/scssphp/scssphp)            | SCSS compilation  |
| [oyejorge/less.php](https://github.com/oyejorge/less.php)        | LESS compilation  |
| [cssmin/cssmin](https://code.google.com/archive/p/cssmin/)       | CSS minification  |
| [mrclay/minify](https://github.com/mrclay/minify)                | JS minification (pinned to ~2.2, see Known Limitations) |
| [patchwork/jsqueeze](https://github.com/nicolas-grekas/JSqueeze) | JS compression    |

## Known limitations

### mrclay/minify is pinned to ~2.2

The JS minification relies on `\\JSMin::minify()` from `mrclay/minify`. This class (`min/lib/JSMin.php`) was removed in version 3.0.0 of that package, so upgrading to `~3.0` or `~4.0` will break JS minification with a "class not found" error.

Do not upgrade `mrclay/minify` in `core/components/modxminify/assetic/composer.json` without replacing the `JSMinFilter` with an alternative. The upstream package authors themselves recommend against using it for new projects — it does not handle modern JavaScript syntax well.

# Free Extra
This is a free extra and the code is publicly available for you to change. The extra is being actively maintained and you\'re free to put in pull requests which match our roadmap. Please create an issue if the pull request differs from the roadmap so we can make sure we\'re on the same page.

Need help? [Approach our support desk for paid premium support.](mailto:service@sterc.com)

## License

GPL v2 — see [LICENSE.md](LICENSE.md).
',
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'changelog' => 'Changelog for modxMinify.

ModxMinify 1.0.5 (2026-05-28)
=============================
- Migrate to new GPM build format (gpm.yml)
- Move CHANGELOG.md to repository root
- Upgrade scssphp to scssphp/scssphp v2.1.0 (requires PHP >= 8.1)
- Fix PHP warning: undefined variable $skip when no cached file exists yet
- Fix group selector in CMP showing only 20 groups (removed default limit)
- Fix CMP intro message showing menu description instead of full intro text
- Add README note for MODX installations in a subdirectory (cache path config)
- Fix fatal error on SCSS syntax errors; log file/line to MODX error log instead of crashing the site

ModxMinify 1.0.4 (2026-05-28)
=============================
- Downgrade scssphp back to leafo/scssphp v0.x for broad PHP compatibility
- Add gpm.yml for new GPM build format

ModxMinify 1.0.3 (2025-02-05)
=============================
- Upgrade ScssPhp by composer

ModxMinify 1.0.2 (2022-11-14)
=============================
- PHP 8 compatibility

ModxMinify 1.0.1 (2018-05-03)
=============================
- Add missing less.php library
- Fix bug with hardcoded \'modx_\' prefix in build (#9 and #25)
- Add cache_path and cache_url settings to override path to minified file (PR#27) - Thanks to @digitalpenguin
- Update composer dependencies
- Remove twig from composer dependencies for better compatibility (#32)

ModxMinify 1.0.0 (2017-01-24)
=============================
- PR release

ModxMinify 0.2.0 (2016-05-25)
=============================
- Added ability to combine multiple groups in one modxMinify call.

ModxMinify 0.1.9 (2016-02-11)
=============================
- Added plugin to clear ModxMinify cache files on Modx cache clear.
- Fixed exception bug in Leafo class
- Added (and removed :p) config.json for groups/files

ModxMinify 0.1.7 (2016-01-20)
=============================
- New css uri rewrite filter (for rewriting relative urls in css files)
- New css minify filter
- fix assetwriter paths

ModxMinify 0.1.6 (2016-01-18)
=============================

ModxMinify 0.1.5 (2016-01-15)
=============================
- Updated Assetic library to latest version
- Added support for .less files
- Fix file extension check in minify class

ModxMinify 0.1 (2015-12-18)
=============================
- Initial release.
',
    'setup-options' => 'modxminify-1.0.5-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '882c50c979696c5814b82af852602bfe',
      'native_key' => 'modxminify',
      'filename' => 'MODX/Revolution/modNamespace/b13e0d59fbe7540455a81c33612e268e.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '71fbe14d8e5bed4395698ff0483be50f',
      'native_key' => 'modxminify.user_name',
      'filename' => 'MODX/Revolution/modSystemSetting/cd2b06918f5727c41365db12e63a7edc.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '886bf1eafb10f6189586f20d011ffb19',
      'native_key' => 'modxminify.user_email',
      'filename' => 'MODX/Revolution/modSystemSetting/fb1657e2ad76e1ed0c1174bf2d89997c.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '680d19cc62e2602fee3494097613869b',
      'native_key' => 'modxminify.cache_path',
      'filename' => 'MODX/Revolution/modSystemSetting/edd9432061c757566e78cfcedc34783d.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac387f8fff37a4cbccb3b52b4e49290f',
      'native_key' => 'modxminify.cache_url',
      'filename' => 'MODX/Revolution/modSystemSetting/5d61909dafa93e066f08cfd3df737cec.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'e6a90cc49b6776b12fc800698f8f7cc2',
      'native_key' => 'e6a90cc49b6776b12fc800698f8f7cc2',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/219b18a01cd14efddc3d9d6e5f043765.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '302dce4f690c6779ee4816f9aa5f00f3',
      'native_key' => 'modxminify.menu.modxminify',
      'filename' => 'MODX/Revolution/modMenu/e08d01a1af41c5285a8a43b6d6389a6f.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'bb75ca1ebf0391baa0f0a466acb59d21',
      'native_key' => 'bb75ca1ebf0391baa0f0a466acb59d21',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/3de7357876bdc95bc3be12fdf2ece643.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '3214576916d3c73ffdc0bb650c7cbab2',
      'native_key' => '3214576916d3c73ffdc0bb650c7cbab2',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/c1f80ba4cf458c891863a2f9506a93c5.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '1b32babd234e09605b2c44a8fb693e9e',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/0ada35a9f07dd6737f371f785f907191.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'e6f16c5d8573ede623c6c4984139ac74',
      'native_key' => 'e6f16c5d8573ede623c6c4984139ac74',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/7df2ce016382dbf182d2877bd4704900.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '991595d5e2397c23f177eaa4dbebd937',
      'native_key' => '991595d5e2397c23f177eaa4dbebd937',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/08c8abd5c0d7ca508014364ea86404d2.vehicle',
    ),
  ),
);