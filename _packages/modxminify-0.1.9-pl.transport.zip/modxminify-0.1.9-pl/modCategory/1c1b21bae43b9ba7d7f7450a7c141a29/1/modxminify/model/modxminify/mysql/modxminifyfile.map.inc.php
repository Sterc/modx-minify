<?php
/**
 * @package modxminify
 */
$xpdo_meta_map['modxMinifyFile']= array (
  'package' => 'modxminify',
  'version' => '0.1',
  'table' => 'minify_files',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'filename' => '',
    'position' => NULL,
    'group' => 0,
  ),
  'fieldMeta' => 
  array (
    'filename' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => false,
      'default' => '',
    ),
    'position' => 
    array (
      'dbtype' => 'int',
      'precision' => '10',
      'phptype' => 'integer',
      'null' => false,
    ),
    'group' => 
    array (
      'dbtype' => 'int',
      'precision' => '10',
      'phptype' => 'integer',
      'null' => false,
      'default' => 0,
    ),
  ),
  'aggregates' => 
  array (
    'Group' => 
    array (
      'class' => 'modxMinifyGroup',
      'local' => 'group',
      'foreign' => 'id',
      'cardinality' => 'one',
      'owner' => 'foreign',
    ),
  ),
);
