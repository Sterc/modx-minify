<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# Modx Minify

Modx Minify is a MODX CMP to group and minify your CSS, SCSS, LESS and JS files. You can create groups, and each group can contain multiple files of the same type. So for instance you create a group named \'css\' where you can add all your css, scss and less files. After that you place the snippet call ``[[!modxMinify?&group=`css`]]`` inside a `<link>` tag in your head and a minified css file will be generated which will contain all your files grouped and minified!

## Usage
* Install the package via Package Management
* Add groups and files via the cmp
* Inside your <head> in your template, place the snippet call, for example: 

``<link rel="stylesheet" type="text/css" href="[[!modxMinify?&group=`css`]]" />``

The modxMinify snippet generates one minified file from all the files added to your specified group. The snippet automatically detects changes in your files, and also checks for changes made in the CMP (adding, updating, removing or reordering of files).

## Combining groups
You can also combine multiple groups into one minified file, by using a comma-separated list of groups in your [[!modxMinify]] snippet call:

``[[!modxMinify?&group=`css,css2`]]``

In the above example all the files from group \'css\' and \'css2\' get combined into one minified CSS file.

# Free Extra
This is a free extra and the code is publicly available for you to change. The extra is being actively maintained and you\'re free to put in pull requests which match our roadmap. Please create an issue if the pull request differs from the roadmap so we can make sure we\'re on the same page.

Need help? [Approach our support desk for paid premium support.](mailto:service@sterc.com)
',
    'setup-options' => 'modxminify-1.0.3-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '15f7e19d210ca29d641f6ffa6780a3ce',
      'native_key' => 'modxminify',
      'filename' => 'MODX/Revolution/modNamespace/b1fee20d26684f074e516942c391cc1d.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd12d2d52e71054ae41ba46d47c5b7dfb',
      'native_key' => 'modxminify.user_name',
      'filename' => 'MODX/Revolution/modSystemSetting/ff123007aae670fea10c534338045830.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '448542ba6717012a03b10d01ec63b5a6',
      'native_key' => 'modxminify.user_email',
      'filename' => 'MODX/Revolution/modSystemSetting/bab7fc67bbf71a1f31f33b973bd318b7.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3848fb22ed7ccd4afd76c5226a98d21b',
      'native_key' => 'modxminify.cache_path',
      'filename' => 'MODX/Revolution/modSystemSetting/481edf8754e675476e9dcfa3a192e838.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c958b66f01a8399c479e2bd0cc0fc763',
      'native_key' => 'modxminify.cache_url',
      'filename' => 'MODX/Revolution/modSystemSetting/8e02b51c64082ccffcde957882e80832.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '8e3c1e97178613cf749863b628f07e20',
      'native_key' => '8e3c1e97178613cf749863b628f07e20',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/5602db5a0b6df00762c8b52c6a9d85f2.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'e55b7b53557e4f36b5326470ed3bdf37',
      'native_key' => 'modxminify.menu.modxminify',
      'filename' => 'MODX/Revolution/modMenu/0153071a552c352038209cd382638192.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '70219e57690b553a6bcfd61bfcb1d2dd',
      'native_key' => '70219e57690b553a6bcfd61bfcb1d2dd',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/86902e2895ad53e34f872aef368ed34e.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '6bfaf3df6b6dee7932b75d043a4c461f',
      'native_key' => '6bfaf3df6b6dee7932b75d043a4c461f',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/99ddea2d736853078c7858c1173258e2.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'fbd3ce10ec6c5727220071e5d83b83cd',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/2a8667d6ff7768a790cfe0fcea4d8e8a.vehicle',
    ),
  ),
);