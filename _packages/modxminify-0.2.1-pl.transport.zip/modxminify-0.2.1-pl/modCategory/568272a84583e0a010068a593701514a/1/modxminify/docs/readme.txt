---------------------------------------
modxMinify
---------------------------------------
Version: 0.2.0
Author: Joeke Kloosterman <joeke@sterc.nl>
---------------------------------------
Modx Minify is a MODX CMP to group and minify your CSS, SCSS, LESS and JS files.