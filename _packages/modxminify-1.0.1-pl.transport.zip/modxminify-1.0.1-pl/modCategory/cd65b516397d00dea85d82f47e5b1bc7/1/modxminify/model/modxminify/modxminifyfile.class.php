<?php
/**
 * @package modxminify
 */
class modxMinifyFile extends xPDOSimpleObject {}
?>