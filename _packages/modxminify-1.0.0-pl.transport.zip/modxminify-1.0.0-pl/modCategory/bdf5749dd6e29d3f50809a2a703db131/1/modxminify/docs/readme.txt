---------------------------------------
modxMinify
---------------------------------------
Version: 1.0.0
Author: Sterc <modx@sterc.nl>
---------------------------------------
Modx Minify is a MODX CMP to group and minify your CSS, SCSS, LESS and JS files.